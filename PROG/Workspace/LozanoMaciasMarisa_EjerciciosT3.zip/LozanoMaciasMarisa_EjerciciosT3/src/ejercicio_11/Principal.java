package ejercicio_11;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Crear un programa para poner las notas de un alumno (clase Alumno con atributos). Los atributos de un alumno son su nombre, curso, un array de notas, número de suspensos y nota media.
		En una clase GestionNotas, el programa debe poder poner notas a un solo alumno, mostrar todas sus notas por pantalla, modificar una nota, calcular la media y dar su número de suspensos.
			Probar todo en la clase Principal.*/

	}

}
