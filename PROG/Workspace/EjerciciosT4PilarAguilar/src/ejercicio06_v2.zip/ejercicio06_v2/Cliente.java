package ejercicio06_v2;

public class Cliente {

	private int nCliente;
	private String nombre;
	
}
