let mensaje = "No olvides añadir comentarios al código";
alert(mensaje);