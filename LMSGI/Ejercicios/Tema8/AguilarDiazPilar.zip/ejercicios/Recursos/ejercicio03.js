let meses = [
    "Enero",
    " Febrero",
    " Marzo",
    " Abril",
    " Mayo", 
    " Junio", 
    " Julio",
    " Agosto",
    " Septiembre", 
    " Octubre", 
    " Noviembre", 
    " Diciembre"
];
alert(meses);

for (const i of meses) {
    alert(meses[])
}