package ejercicio01;

import java.lang.Exception;

public class ExcepcionCodigo extends Exception{

	
	
}
