package ejercicio01;

public interface IAterrizaje {

	
	public double calcularPrecioAterrizaje(int id, double porcentaje);
	
	
}
