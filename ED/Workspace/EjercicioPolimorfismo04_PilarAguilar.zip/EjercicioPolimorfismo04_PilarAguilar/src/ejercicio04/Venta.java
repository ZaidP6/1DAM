package ejercicio04;

public class Venta {

	
	public LineadeVenta [] listaVentas;
	
	
	
}
