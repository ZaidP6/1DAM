package ejercicio04;

public class LineadeVenta {

	public Producto p;
	public int cantidad;
	
	
}
